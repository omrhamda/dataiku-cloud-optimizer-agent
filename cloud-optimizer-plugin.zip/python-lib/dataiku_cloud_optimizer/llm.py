"""Very small LLM wrapper stub for summarization inside DSS.

If OpenAI key provided, attempts to call OpenAI ChatCompletion (lazy import).
Falls back to heuristic summary.
"""
from __future__ import annotations
from typing import Any, Dict, List
import json
import os

class SimpleLLM:
    def __init__(self, api_key: str | None, model: str = "gpt-4o-mini", max_tokens: int = 512) -> None:
        self.api_key = api_key
        self.model = model
        self.max_tokens = max_tokens
        self._client = None  # lazy

    def _ensure_client(self) -> None:
        if self.api_key and self._client is None:
            try:  # pragma: no cover - optional dependency
                from openai import OpenAI  # type: ignore
                self._client = OpenAI(api_key=self.api_key)
            except Exception:
                self._client = None

    def summarize(self, base_summary: str, context: Dict[str, Any]) -> str:
        if not self.api_key:
            return base_summary
        self._ensure_client()
        if self._client is None:
            return base_summary
        try:  # pragma: no cover - network call not tested
            prompt = (
                "You are a FinOps assistant. Using the JSON context below, produce a concise, executive "
                "summary (<= 120 words) focusing on total savings and top opportunities.\nContext:\n"
                + json.dumps(context) + "\nBase Summary:\n" + base_summary
            )
            resp = self._client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=self.max_tokens,
                temperature=0.2,
            )
            choice = resp.choices[0]
            return getattr(choice.message, "content", base_summary) or base_summary
        except Exception:
            return base_summary
