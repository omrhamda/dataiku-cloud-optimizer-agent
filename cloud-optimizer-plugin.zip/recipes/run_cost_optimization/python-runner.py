# -*- coding: utf-8 -*-
"""Recipe runner for Cloud Cost Optimization.

Reads plugin & recipe params, instantiates the agent with minimal config,
executes optimization, and writes recommendations to the output dataset.
"""
from __future__ import annotations

import json
from textwrap import dedent
from typing import Any, Dict, List

# Dataiku APIs
from dataiku import Dataset, recipe_config, plugin_config  # type: ignore

# Import agent pieces (assuming the package copied into python-lib)
from dataiku_cloud_optimizer import (
    CloudOptimizerAgent,
    AWSProvider,
    AzureProvider,
    GCPProvider,
    CostOptimizationStrategy,
    SimpleLLM,
    SlackNotifier,
    EmailNotifier,
)


def _parse_yaml_config(raw: str | None) -> Dict[str, Any]:
    if not raw:
        return {}
    try:  # pragma: no cover - optional dependency & edge parsing
        import yaml  # type: ignore

        return yaml.safe_load(raw) or {}
    except Exception:
        return {}


def _build_agent(pconf: Dict[str, Any]) -> CloudOptimizerAgent:
    cfg = _parse_yaml_config(pconf.get("default_config_yaml"))
    providers_cfg: Dict[str, Any] = cfg.get("providers", {}) if isinstance(cfg, dict) else {}
    strategies_cfg: Dict[str, Any] = cfg.get("strategies", {}) if isinstance(cfg, dict) else {}

    agent = CloudOptimizerAgent()
    # Providers with optional per-provider configs
    agent.register_provider("aws", AWSProvider(providers_cfg.get("aws")))
    agent.register_provider("azure", AzureProvider(providers_cfg.get("azure")))
    agent.register_provider("gcp", GCPProvider(providers_cfg.get("gcp")))
    # Strategy config
    cost_cfg = strategies_cfg.get("cost") if isinstance(strategies_cfg, dict) else None
    agent.register_strategy("cost", CostOptimizationStrategy(cost_cfg))

    # LLM wiring (optional)
    api_key = pconf.get("openai_api_key") or None
    if api_key:
        llm_model = pconf.get("llm_model") or "gpt-4o-mini"
        max_tokens = int(pconf.get("llm_max_tokens") or 512)
        agent.llm = SimpleLLM(api_key=api_key, model=llm_model, max_tokens=max_tokens)  # type: ignore[attr-defined]

    # Notifications (optional)
    if pconf.get("notifications_enabled", True):
        slack_url = pconf.get("slack_webhook_url") or None
        if slack_url:
            agent.register_notifier("slack", SlackNotifier(slack_url))  # type: ignore[attr-defined]
        emails = pconf.get("email_recipients") or ""
        if emails.strip():
            agent.register_notifier("email", EmailNotifier(emails))  # type: ignore[attr-defined]
    return agent


def _run_cost_optimization(agent: CloudOptimizerAgent, strategies: List[str]) -> List[Dict[str, Any]]:
    # Currently only one strategy example; extend when multiple.
    results: List[Dict[str, Any]] = []
    for strat in strategies:
        if strat == "cost":
            recs = agent.run_strategy("cost")  # type: ignore[arg-type]
            if isinstance(recs, list):
                for r in recs:
                    if isinstance(r, dict):
                        results.append(r)
    return results


def _write_output(dataset_name: str, rows: List[Dict[str, Any]]) -> None:
    ds = Dataset(dataset_name)
    # Infer columns from union of keys.
    all_keys = []
    seen = set()
    for r in rows:
        for k in r.keys():
            if k not in seen:
                seen.add(k)
                all_keys.append(k)
    schema = [{"name": k, "type": "string"} for k in all_keys]
    ds.write_schema(schema)
    ds.write_with_schema(rows)


def main() -> None:
    rconf = recipe_config()
    pconf = plugin_config()

    strategies_raw = rconf.get("strategies", "cost")
    strategies = [s.strip() for s in strategies_raw.split(",") if s.strip()] or ["cost"]

    # Output dataset - Dataiku provides via config
    # Input/Output names are in recipe inputs/outputs; here we discover first output.
    from dataiku import get_custom_variables  # type: ignore
    # Fallback: assume one output dataset declared, accessible via env variable inside DSS runtime.

    # Dataiku provides a helper: we can also list outputs via recipe libraries; to keep simple, use Dataset API directly.
    output_dataset_names = []
    try:
        from dataiku import get_recipe_output_names  # type: ignore

        output_dataset_names = get_recipe_output_names()["main"]
    except Exception:  # pragma: no cover - defensive
        pass

    if not output_dataset_names:
        raise RuntimeError("No output dataset configured for this recipe")

    output_ds = output_dataset_names[0]

    agent = _build_agent(pconf)
    recs = _run_cost_optimization(agent, strategies)

    # Serialize nested objects to JSON strings for consistency
    serializable_rows: List[Dict[str, Any]] = []
    for r in recs:
        row: Dict[str, Any] = {}
        for k, v in r.items():
            if isinstance(v, (dict, list)):
                row[k] = json.dumps(v)
            else:
                row[k] = v
        serializable_rows.append(row)

    _write_output(output_ds, serializable_rows)

    # Optional summary & notify (if configured)
    if getattr(agent, "llm", None) or agent.notifiers:  # type: ignore[attr-defined]
        # Construct simple results object shape for summarization
        try:
            summary_base = f"Produced {len(serializable_rows)} recommendations across strategies {','.join(strategies)}"
            if getattr(agent, "llm", None):
                context = {"count": len(serializable_rows), "strategies": strategies}
                final_summary = agent.llm.summarize(summary_base, context)  # type: ignore[attr-defined]
            else:
                final_summary = summary_base
            if agent.notifiers:  # type: ignore[attr-defined]
                for name, notifier in agent.notifiers.items():  # type: ignore[attr-defined]
                    try:
                        notifier.send(final_summary)
                    except Exception:
                        pass
        except Exception:
            pass


if __name__ == "__main__":  # pragma: no cover
    main()
